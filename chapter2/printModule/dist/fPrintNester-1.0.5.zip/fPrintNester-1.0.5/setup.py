
from distutils.core import setup

setup(
    name = 'fPrintNester',
    version = '1.0.5',
    py_modules = ['PrintNester'],
    author = "qsl",  
    author_email = "Qsl_xj@outlook.com",
    url = "http://test.com",
    description = '修改第四版本运行错误'
    )
    


'''
from setuptools import setup
  
setup(  
    name = "nester",  
    version = "1.0.0",
    py_modules = ['nester'],
      
    author = "qsl",  
    author_email = "Qsl_xj@outlook.com",
    url = "http://test.com",
    
    description = 'A simple printer of nested lists'

)

'''
