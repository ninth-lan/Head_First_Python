from distutils.core import setup

setup(
    name = 'athletestlist',
    version = '1.0.0',
    py_modules = ['athletelist'],
    author = 'qsl',
    author_email = 'Qsl_xj@outlook.com',
    url = "http://test.com",
    description = '运动员时间表示'
    )
